Emrullah KARAKO� B171210002
Yunus �EN B171210098

98-02=96(mod26)=18 => L-BLOCK 

	proje c dilinde yaz�l�p derlemek icin consolda dosya klos�r�n� ac�p
            
                  gcc LBLOCK.c -o lblock 

     	yazarak exe dosyas�n� proje klos�r�nde olu�turup acabilirsiniz.