/****************************************************************************
**										SAKARYA �N�VERS�TES�
**							 B�LG�SAYAR VE B�L���M B�L�MLER� FAK�LTES�
**									B�LG�SAYAR M�HEND�SL��� B�L�M�
**									 PROGRAMLAMAYA G�R��� DERS�
**
**				�DEV NUMARASI�...:			�DEV 4
**				��RENC� ADI...............: EMRULLAH KARAKO�
**				��RENC� NUMARASI.:			B171210002
**				DERS GRUBU����:				1.  ��RET�M A GRUBU
****************************************************************************/

#include <iostream>
#include <time.h>

using namespace std;



bool elemanKontrol(int matris[10][10])
{
	int kontrol = 0;
	for (int i = 0;i < 10;i++)
	{
		for (int j = 0;j < 10;j++)
		{
			for (int a = 0;a < 10;a++)
			{
				for (int b = 0;b < 10;b++)
				{
					if (a == i && b == j)						// D�Z�N�N AYNI ELEMANINI KEND� �ZER�NDE KONTROL ETMES�N� �NLEMEK ���N YAZILAN �F BLO�U
						continue;
					if (matris[i][j] == matris[a][b])
					{
						matris[a][b] = 0;						// B�RDEN FAZLA AYNI ELEMAN VARSA B�R� HAR�� D��ERLER�N� 0 YAPACAK.
						kontrol++;								// E�ER kontol DE���KEN� E��TL�K DURUMUNDA BURAYA G�RERSE AYNI ELEMAN VAR DEMEKT�R VE FALSE D�ND�RMES�N� SA�LAYACAK.
					}
				}
			}
		}
	}

	if (kontrol != 0)											// D�Z� ARASINDAK� ELEMANLARDA E��TL�K DURUMUNA G�R�P G�RMED���N� KONTROL EDER.
	{
		return false;
	}
	else
		return true;
}


void olustur(int matris[10][10])
{
	int randsayisi = 0;									// KA� KEZ RASTGELE �A�IRIM YAPACA�IMIZI TUTTU�UMUZ �NDEX
	for (int i = 0;i < 10;i++)
	{
		for (int j = 0;j < 10;j++)
		{
			matris[i][j] = (rand() % 100) + 1;			// �LK BA�TA T�M ELEMANLARA RANDOM SAYI ATADIK
			randsayisi++;
		}
	}


	while (elemanKontrol(matris) == false)
	{
		for (int i = 0;i < 10;i++)
		{
			for (int j = 0;j < 10;j++)
			{
				if (matris[i][j] == 0)							//MATR�S�N 0 OLAN ELEMANLARINA TEKRARDAN RANDOM ELEMAN ATAMAK ���N
				{
					matris[i][j] = (rand() % 100) + 1;
					randsayisi++;
				}
			}
		}
	}

	cout << " Rastgele cagirim adedi = " << randsayisi << endl;
}


void matrisYaz(int matris[10][10])
{
	for (int i = 0;i < 10;i++)
	{
		for (int j = 0;j < 10;j++)
		{
			cout << matris[i][j] << "\t";				// MATR�S�N HER ELEMANI ARASINDA B�R TAB KADAR BO�LUK KOYDUK
			if (j == 9)
				cout << endl;
		}
	}
}


void sirala(int matris[10][10])
{
	for (int i = 0;i < 10;i++)
	{
		for (int j = 0;j < 10;j++)
		{
			for (int a = 0;a < 10;a++)
			{
				for (int b = 0;b < 10;b++)
				{
					if (matris[i][j] > matris[a][b])
					{
						int temp = matris[i][j];
						matris[i][j] = matris[a][b];
						matris[a][b] = temp;

					}
				}
			}
		}
	}
}


int main()
{
	int matris[10][10];

	srand(time(0));
	olustur(matris);


	cout << "***** Rastgele olusan ve elemanlari farkli matris *****" << endl;
	matrisYaz(matris);

	sirala(matris);
	cout << endl << endl;

	cout << "***** Buyukten kucuge siralanmis matris *****" << endl;
	matrisYaz(matris);

	cout << endl << endl;
	system("pause");
}