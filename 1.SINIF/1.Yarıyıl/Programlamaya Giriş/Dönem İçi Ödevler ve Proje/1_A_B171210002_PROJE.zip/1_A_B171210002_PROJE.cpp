/****************************************************************************
**										SAKARYA �N�VERS�TES�
**							 B�LG�SAYAR VE B�L���M B�L�MLER� FAK�LTES�
**									B�LG�SAYAR M�HEND�SL��� B�L�M�
**									 PROGRAMLAMAYA G�R��� DERS�
**
**				�DEV NUMARASI�...:			PROJE �DEV�
**				��RENC� ADI...............: EMRULLAH KARAKO�
**				��RENC� NUMARASI.:			B171210002
**				DERS GRUBU����:				1.  ��RET�M A GRUBU
****************************************************************************/
#include <iostream>
#include <string>
#include <fstream>

using namespace std;


int  AnaMen�();
void OdaMen�();
void M�steriMen�();

fstream OdaKaydet;
fstream m�sterikayd�;
fstream Kay�tislemleri;

int secim;


class M�steri
{
public:
	string ad;
	string soyad;
	long long tckimlik;
	int m�sterino;

	int  silinecekm�steri;


	fstream SilinmisM�steri;

	void M�steriMen�()
	{
		int girilenm�sterimen�;
		system("cls");
		cout << " 1- Musteri Ekle " << endl;
		cout << " 2- Musteri sil " << endl;
		cout << " 3- Musteri Listele " << endl;
		cout << " 99- Ust Menu " << endl;
		cout << " Seciminiz....:";
		cin >> secim;
		if (secim == 1)
		{
			system("cls");
			M�steriEkle();

		}
		else if (secim == 2)
		{
			system("cls");
			M�steriSil();

		}
		else if (secim == 3)
		{
			system("cls");
			M�steriG�r�nt�le();
		}
		else if (secim == 99)
		{
			system("cls");
			AnaMen�();

		}
		else
		{
			system("cls");
			cout << "***** Yanlis Secim Yaptiniz *****" << endl;
		}

	}

	void M�steriEkle()
	{

		do
		{
			M�steri m�steri;

			system("cls");
			cout << " AD..:";
			cin >> m�steri.ad;
			cout << endl;
			cout << " SOYAD..:";
			cin >> m�steri.soyad;
			cout << endl;
			cout << " TC..:";
			cin >> m�steri.tckimlik;
			cout << endl;
			cout << " MUSTERI NO..:";
			cin >> m�steri.m�sterino;

			m�sterikayd�.open("M�steri.txt", ios::in | ios::out | ios::app);
			m�sterikayd�.setf(ios::left);
			m�sterikayd� << m�steri.m�sterino << "\t" << m�steri.tckimlik << "\t" << m�steri.ad << "\t" << m�steri.soyad << "\t" << endl;
			m�sterikayd�.close();

			system("cls");
			cout << " 1-Musteri eklemeye devam et" << endl;
			cout << " 2 Ust Menu" << endl;
			cout << " Seciminiz.....: ";
			cin >> secim;
		}

		while (secim == 1);


		if (secim == 2)
			M�steriMen�();

		if (secim != 1 && secim != 2)
		{
			system("cls");
			cout << "***** Yanlis Secim *****" << endl;
		}

	}

	void M�steriSil()
	{
		do
		{
			system("cls");
			ofstream dosyaYaz;
			M�steri m1;

			m�sterikayd�.open("M�steri.txt");
			dosyaYaz.open("silinmis.txt", ios::app);

			cout << " Silinecek Musterinin Musteri Numarasi.....: ";
			cin >> silinecekm�steri;

			while (!m�sterikayd�.eof())
			{
				m�sterikayd� >> m1.m�sterino >> m1.tckimlik >> m1.ad >> m1.soyad;
				if (m�sterikayd�.eof())
					break;

				if (silinecekm�steri != m1.tckimlik)
				{
					if (m�sterikayd�.eof())
						break;
					dosyaYaz << m1.m�sterino << "\t" << m1.tckimlik << "\t" << m1.ad << "\t" << m1.soyad << endl;

				}

				else
				{
					continue;
				}
			}
			m�sterikayd�.close();
			dosyaYaz.close();

			remove("M�steri.txt");
			rename("silinmis.txt", "M�steri.txt");


			system("cls");
			cout << " 1-Musteri Silmeye Devam Et" << endl;
			cout << " 2 Ust Menu" << endl;
			cout << " Seciminiz.....: ";
			cin >> secim;
		}

		while (secim == 1);


		if (secim == 2)
			M�steriMen�();

		if (secim != 1 && secim != 2)
		{
			system("cls");
			cout << "***** Yanlis Secim *****" << endl;
		}
	}

	void M�steriG�r�nt�le()
	{
		system("cls");
		m�sterikayd�.open("M�steri.txt", ios::in | ios::out | ios::app);
		M�steri m1;

		cout << "				----Musteri Bilgileri----				 " << endl;
		while (!m�sterikayd�.eof())
		{
			m�sterikayd� >> m1.m�sterino >> m1.tckimlik >> m1.ad >> m1.soyad;

			if (m�sterikayd�.eof())
				break;									//Dosya sonuna geldiyse son sat�r iki kere okunmas�n diye ��k��

			cout << " Musteri No : " << m1.m�sterino << "\t" << " Musteri TC  : " << m1.tckimlik << "\t" << " Musteri Ad  : " << m1.ad << "\t" << " Musteri Soyad  : " << m1.soyad << endl;

		}

		m�sterikayd�.close();
		cout << endl;


		cout << " 1- Ust Menu" << endl;
		cout << " Seciminiz.....: ";
		cin >> secim;


		if (secim == 1)
			M�steriMen�();

		if (secim != 1)
		{
			system("cls");
			cout << "***** Yanlis Secim *****" << endl;
		}

	}

};

class Oda
{

public:
	int odanumarasi;
	int oda�creti;
	int silinecekOda;

	fstream SilinmisOda;

	void OdaMen�()
	{
		system("cls");
		cout << " 1- Oda Ekle " << endl;
		cout << " 2- Oda Sil " << endl;
		cout << " 3- Odalari Listele " << endl;
		cout << " 99- Ust Menu " << endl;
		cout << " Seciminiz....:";
		cin >> secim;
		if (secim == 1)
		{
			system("cls");
			OdaEkle();

		}
		else if (secim == 2)
		{
			system("cls");
			OdaSil();
		}
		else if (secim == 3)
		{
			system("cls");
			OdalariG�r�nt�le();

		}
		else if (secim == 99)
		{
			system("cls");
			AnaMen�();

		}
		else
		{
			system("cls");
			cout << "***** Yanlis Secim Yaptiniz *****" << endl;
		}
	}

	void OdaEkle()
	{

		do
		{
			Oda oda;
			system("cls");
			cout << " Oda numarasi...:";
			cin >> oda.odanumarasi;
			cout << endl;

			cout << " Oda ucreti...:";
			cin >> oda.oda�creti;
			cout << endl;

			OdaKaydet.open("Oda.txt", ios::in | ios::out | ios::app);
			OdaKaydet << oda.odanumarasi << "\t" << oda.oda�creti << endl;
			OdaKaydet.close();

			system("cls");
			cout << " 1-Oda eklemeye devam et" << endl;
			cout << " 2 Ust Menu" << endl;
			cout << " Seciminiz.....: ";
			cin >> secim;
		}

		while (secim == 1);


		if (secim == 2)
			OdaMen�();

		if (secim != 1 && secim != 2)
		{
			system("cls");
			cout << "***** Yanlis Secim *****" << endl;
		}


	}

	void OdaSil()
	{
		do
		{
			system("cls");
			ofstream dosyaYaz;
			Oda o1;

			OdaKaydet.open("oda.txt");
			dosyaYaz.open("silinmis.txt", ios::app);

			cout << " Silinecek Oda Numarasi : ";
			cin >> silinecekOda;

			while (!OdaKaydet.eof())
			{
				OdaKaydet >> o1.odanumarasi >> o1.oda�creti;
				if (OdaKaydet.eof()) break;

				if (silinecekOda != o1.odanumarasi)
				{
					if (OdaKaydet.eof())
						break;
					dosyaYaz << o1.odanumarasi << "\t" << o1.oda�creti << endl;

				}

				else
				{
					continue;
				}
			}
			OdaKaydet.close();
			dosyaYaz.close();

			remove("oda.txt");
			rename("silinmis.txt", "oda.txt");


			system("cls");
			cout << " 1-Oda Silmeye Devam Et" << endl;
			cout << " 2 Ust Menu" << endl;
			cout << " Seciminiz.....: ";
			cin >> secim;
		}

		while (secim == 1);


		if (secim == 2)
			OdaMen�();

		if (secim != 1 && secim != 2)
		{
			system("cls");
			cout << "***** Yanlis Secim *****" << endl;
		}

	}

	void  OdalariG�r�nt�le()
	{
		OdaKaydet.open("oda.txt");
		Oda o1;
		system("cls");
		cout << " ----Oda Bilgileri---- " << endl;
		while (!OdaKaydet.eof())
		{
			OdaKaydet >> o1.odanumarasi >> o1.oda�creti;

			if (OdaKaydet.eof())
				break;									//Dosya sonuna geldiyse son sat�r iki kere okunmas�n diye ��k��

			cout << " Oda No : " << o1.odanumarasi << "\t" << " Oda Ucreti : " << o1.oda�creti << endl;

		}

		OdaKaydet.close();
		cout << endl;


		cout << " 1- Ust Menu" << endl;
		cout << " Seciminiz.....: ";
		cin >> secim;


		if (secim == 1)
			OdaMen�();

		if (secim != 1)
		{
			system("cls");
			cout << "***** Yanlis Secim *****" << endl;
		}

	}

};

class Odaislemleri
{
public:
	int kaydedilecekodano;
	int kaydedilecekM�sterino;

	void Kay�tMen�()
	{
		int girilenm�sterimen�;
		system("cls");
		cout << " 1- Musteri'yi Odaya Kaydet " << endl;
		cout << " 2- Kayitlari Goruntule " << endl;
		cout << " 99- Ust Menu " << endl;
		cout << " Seciminiz....:";
		cin >> secim;
		if (secim == 1)
		{
			system("cls");
			M�steriOdayaKay�t();
		}
		else if (secim == 2)
		{
			system("cls");
			Kay�tG�r�nt�le();
		}
		else if (secim == 99)
		{
			system("cls");
			AnaMen�();

		}
		else
		{
			system("cls");
			cout << "***** Yanlis Secim Yaptiniz *****" << endl;
		}
	}

	void M�steriOdayaKay�t()
	{
		do
		{
			Odaislemleri odakay�t1;
			system("cls");
			cout << " Kayit Yapilacak Oda numarasi...:";
			cin >> odakay�t1.kaydedilecekodano;
			cout << endl;

			cout << " Kayit Yapilacak Musteri no...:";
			cin >> odakay�t1.kaydedilecekM�sterino;
			cout << endl;


			OdaKaydet.open("Oda.txt", ios::in | ios::out | ios::app);
			m�sterikayd�.open("M�steri.txt", ios::in | ios::out | ios::app);
			Kay�tislemleri.open("OtelKay�t.txt", ios::in | ios::out | ios::app);

			while (!OdaKaydet.eof())
			{
				Oda OM1;

				if (OdaKaydet.eof())
					break;

				OdaKaydet >> OM1.odanumarasi >> OM1.oda�creti;

				if (odakay�t1.kaydedilecekodano == OM1.odanumarasi)
					Kay�tislemleri << OM1.odanumarasi << "\t" << OM1.oda�creti << "\t";

			}


			while (!m�sterikayd�.eof())
			{
				M�steri KM1;
				if (m�sterikayd�.eof())
					break;

				m�sterikayd� >> KM1.m�sterino >> KM1.tckimlik >> KM1.ad >> KM1.soyad;

				if (odakay�t1.kaydedilecekM�sterino == KM1.m�sterino)
					Kay�tislemleri << KM1.m�sterino << "\t" << KM1.tckimlik << "\t" << KM1.ad << "\t" << KM1.soyad << endl;

			}

			OdaKaydet.close();
			m�sterikayd�.close();
			Kay�tislemleri.close();

			system("cls");

			cout << " 1-Kayit Yapmaya Devam Et" << endl;
			cout << " 2 Ust Menu" << endl;
			cout << " Seciminiz.....: ";
			cin >> secim;
		}

		while (secim == 1);


		if (secim == 2)
			Kay�tMen�();

		if (secim != 1 && secim != 2)
		{
			system("cls");
			cout << "***** Yanlis Secim *****" << endl;
		}



	}

	void Kay�tG�r�nt�le()
	{
		system("cls");
		Kay�tislemleri.open("OtelKay�t.txt", ios::in | ios::out | ios::app);
		Oda o1;
		M�steri m1;

		cout << " ---- Kayitli Oda-Musteriler ---- " << endl;
		while (!Kay�tislemleri.eof())
		{
			if (Kay�tislemleri.eof())
				break;

			Kay�tislemleri >> o1.odanumarasi >> o1.oda�creti >> m1.m�sterino >> m1.tckimlik >> m1.ad >> m1.soyad;
			cout << "Oda Numarasi..:" << o1.odanumarasi << "\t" << "Oda Ucreti..:" << o1.oda�creti << "\t" << "Musteri No..:" << m1.m�sterino << "\t" << "Ad..:" << m1.ad << "\t" << "Soyad..:" << m1.soyad << "\t" << "Tc..:" << m1.tckimlik << endl;

		}

		Kay�tislemleri.close();
		cout << endl;


		cout << " 1- Ust Menu" << endl;
		cout << " Seciminiz.....: ";
		cin >> secim;


		if (secim == 1)
			Kay�tMen�();

		if (secim != 1)
		{
			system("cls");
			cout << "***** Yanlis Secim *****" << endl;
		}

	}
};

int AnaMen�()
{

	system("cls");
	cout << "***** OTEL ISLEMLERI *****" << endl;
	cout << "--------------------------" << endl;
	cout << " 1- Oda Islemleri " << endl;
	cout << " 2- Musteri Islemleri " << endl;
	cout << " 3- Oda Kayit Islemleri " << endl;
	cout << " 99- Cikis " << endl;
	cout << " Seciminiz....: ";
	cin >> secim;

	if (secim == 1)
	{
		Oda oda;
		oda.OdaMen�();
	}

	else if (secim == 2)
	{
		M�steri m1;
		m1.M�steriMen�();
	}

	else if (secim == 3)
	{
		Odaislemleri o1;
		o1.Kay�tMen�();
	}
	else if (secim == 99)
	{
		return 0;
	}
	else
	{
		system("cls");
		cout << "***** Yanlis Secim *****" << endl;
	}

}


int main()
{
	AnaMen�();
}