﻿/****************************************************************************
**					           SAKARYA ÜNİVERSİTESİ
**			          BİLGİSAYAR VE BİLİŞİM BİLİMLERİ FAKÜLTESİ
**				           BİLGİSAYAR MÜHENDİSLİĞİ BÖLÜMÜ
**				            PROGRAMLAMAYA GİRİŞİ DERSİ
**
**				ÖDEV NUMARASI…...:           1.1
**				ÖĞRENCİ ADI...............:  EMRULLAH KARAKOÇ
**				ÖĞRENCİ NUMARASI.:           b171210002
**				DERS GRUBU…………:              A
****************************************************************************/


#include <iostream>
#include <iomanip>
using namespace std;

int main()

{

	cout << " Lutfen a>b olacak sekilde a ve b tamsayilarini giriniz....." << endl;
	int a, b, x;
	cout << " a =.........:";
	cin >> a;
	cout << " b =.........:";
	cin >> b;
	cout << " x =............:";
	cin >> x;


	while (b > a)
	{
		cout << endl << "-----------------" << endl << endl;
		cout << "HATALI GIRIS YAPTINIZ.." << endl;
		cout << " a =.........:";
		cin >> a;
		cout << " b =.........:";
		cin >> b;
		cout << " x =............:";
		cin >> x;
		cout << endl << "-----------------" << endl;
	}






	int fonk_bir = 0;
	int fonk_sıfır = 0;
	int fonk_eksibir = 0;

	for (int i = x;i < x + 20;i++)
	{


		if (i > a)		      					 //girilen x değeri a'dan büyükse f(x)=1			
		{
			fonk_bir++;
			continue;
		}
		else if (b <= i && i <= a)			    //girilen x değeri b≤x≤a ise f(x)=0
		{
			fonk_sıfır++;
			continue;
		}
		else(i < b);							//girilen x değeri b'dan küçükse f(x)= -1		
		{
			fonk_eksibir++;
			continue;
		}


	}

	cout << endl << endl << "------------------------------" << endl << endl;

	cout << "1 ";
	for (int j = 0;j < fonk_sıfır + fonk_eksibir + 2;j++)
		cout << " ";
	for (int i = 0;i < fonk_bir;i++)
		cout << "*";
	cout << endl << endl;

	cout << "0 ";
	for (int j = 0;j <fonk_eksibir + 2;j++)
		cout << " ";
	for (int i = 0;i < fonk_sıfır;i++)				//f(x)=0 sayısı kadar * yazdırdık.
		cout << "*";

	cout << endl << endl;

	cout << "-1 ";
	for (int i = 0;i < fonk_eksibir;i++)			//f(x)=-1 sayısı kadar * yazdırdık.
		cout << "*";

	cout << endl << endl;













	system("pause");
}


