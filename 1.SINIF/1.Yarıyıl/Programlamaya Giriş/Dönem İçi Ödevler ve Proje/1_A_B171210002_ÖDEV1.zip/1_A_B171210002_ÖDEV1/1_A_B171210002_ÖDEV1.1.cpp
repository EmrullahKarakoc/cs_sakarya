/****************************************************************************
**					           SAKARYA �N�VERS�TES�
**			          B�LG�SAYAR VE B�L���M B�L�MLER� FAK�LTES�
**				           B�LG�SAYAR M�HEND�SL��� B�L�M�
**				            PROGRAMLAMAYA G�R��� DERS�
**
**				�DEV NUMARASI�...:           1.1
**				��RENC� ADI...............:  EMRULLAH KARAKO�
**				��RENC� NUMARASI.:           b171210002
**				DERS GRUBU����:              A
****************************************************************************/


#include <iostream>
#include <iomanip>
using namespace std;

int main()

{

	for (int i = 0;i < 25;i++)
		cout << "*";
	cout << endl;

	cout << "*" << "SAU BILGISAYAR" << setw(10) << "*" << endl;






	int bosluk = 7;

	for (int i = 0; i < 6; i++)
	{

		if (i == 1 || i == 2)
		{

		}


		if (i == 0)
			cout << "*";
		else
			cout << "*" << setw(bosluk);

		for (int j = 1; j < 2 * i; j++)
			cout << "*";


		if (i != 0)
			cout << setw(2 * bosluk - 1);


		for (int j = 1; j < 2 * i; j++)
			cout << "*";


		if (i == 1 || i == 2)
		{

			if (i == 1)
				cout << "   ***";
			if (i == 2)
				cout << "   *";
		}



		bosluk--;
		if (i == 0)
			cout << setw(bosluk + 18) << "*" << endl;
		else if (i == 1)
			cout << setw(bosluk - 5) << "*" << endl;
		else if (i == 2)
			cout << setw(bosluk - 2) << "*" << endl;
		else
			cout << setw(bosluk + 2) << "*" << endl;

	}


	for (int i = 0;i < 25;i++)
		cout << "*";
	cout << endl;
	cout << "*" << setw(24) << "*" << endl;

	cout << "*" << "MUHENDISLIGI BOLUMU" << setw(5) << "*" << endl;





	int bosluk2 = 7;

	for (int i = 0; i < 6; i++)
	{

		if (i == 0)
			cout << "*";
		else
			cout << "*" << setw(bosluk2);

		for (int j = 1; j < 2 * i; j++)
			cout << "*";

		if (i == 1 || i == 2)
		{

			if (i == 1)
				cout << "   ***";
			if (i == 2)
				cout << "   *";
		}


		if (i != 0)
			cout << setw(2 * bosluk2 - 1);
		if (i == 1)
			cout << setw(2 * bosluk2 - 7);
		if (i == 2)
			cout << setw(2 * bosluk2 - 5);

		for (int j = 1; j < 2 * i; j++)
			cout << "*";


		bosluk2--;
		if (i == 0)
			cout << setw(bosluk2 + 18) << "*" << endl;
		else if (i == 1)
			cout << setw(bosluk + 6) << "*" << endl;
		else if (i == 2)
			cout << setw(bosluk + 5) << "*" << endl;

		else
			cout << setw(bosluk2 + 2) << "*" << endl;

	}




	for (int i = 0;i <= 24;i++)
		cout << "*";
	cout << endl << endl;




	system("pause");
}