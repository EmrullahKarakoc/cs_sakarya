/****************************************************************************
**										SAKARYA �N�VERS�TES�
**							 B�LG�SAYAR VE B�L���M B�L�MLER� FAK�LTES�
**									B�LG�SAYAR M�HEND�SL��� B�L�M�
**									 PROGRAMLAMAYA G�R��� DERS�
**
**				�DEV NUMARASI�...:			�DEV 3
**				��RENC� ADI...............: EMRULLAH KARAKO�
**				��RENC� NUMARASI.:			B171210002
**				DERS GRUBU����:				1.  ��RET�M A GRUBU
****************************************************************************/

#include<iostream>
#include<string>

using namespace std;


void harfsayisi(string);
void kelimesayisi(string);
void terstenaynimi(string);
void noktalama(string);
void kelimeharf(string);
void kelimesesli(string);
void kelimepalindrommu(string);

int main()
{
	string girilen;
	cout << " ********** Lutfen  Metni Giriniz **********" << endl;
	getline(cin, girilen);
	cout << endl;


	harfsayisi(girilen);
	kelimesayisi(girilen);
	terstenaynimi(girilen);
	noktalama(girilen);
	kelimeharf(girilen);
	kelimesesli(girilen);
	kelimepalindrommu(girilen);


	system("pause");
}


void harfsayisi(string girilen1)
{
	int harfsayisi1 = 0;
	for (int i = 0;i < girilen1.length();i++)								// girilen metnin uzunlu�u kadar �al��cak d�ng�..
	{
		if (girilen1[i] > 96 && girilen1[i] < 123)						//K���k harfleri kontrol eden d�ng�
			harfsayisi1++;
		else if (girilen1[i] > 64 && girilen1[i] < 91)					//B�y�k harfleri kontrol eden d�ng�
			harfsayisi1++;

	}

	cout << " Girilen metindeki  harf   sayisi	: " << harfsayisi1 << endl;
}


void kelimesayisi(string girilen1)
{
	int kelimesayisi1 = 1;					// �lk ba�ta bo�luk olmayaca��ndan kelime say�s�n� 1'den ba�latt�k
	for (int i = 0;i < girilen1.length();i++)				// girilen mmetnin uzunlu�u kadar �al��cak d�ng�..
	{
		if (girilen1[i] == ' ')					//Her  bo�lukta kelime say�s�n� bir art�rcak
			kelimesayisi1++;

	}

	cout << " Girilen metindeki  kelime sayisi : " << kelimesayisi1 << endl;

}


void terstenaynimi(string girilen1)
{

	cout << " Girilen metin palindrom mu ? :  ";
	int j = girilen1.length() - 1;
	for (int i = 0;i < girilen1.length() - 1;i++)						// girilen metnin uzunlu�u kadar �al��cak d�ng�..
	{


		if (girilen1[i] < 65 || girilen1[i] > 122)					//B�y�k harfleri kontrol eden d�ng�
			i++;

		if (girilen1[j] < 65 || girilen1[j] > 122)					//B�y�k harfleri kontrol eden d�ng�
			j--;
		if (girilen1[i] > 64 && girilen1[i] < 91)					//B�y�k harfi k���k  harfe d�n��t�recek
			girilen1[i] += 32;

		if (girilen1[j] > 64 && girilen1[j] < 91)					//B�y�k harfi k���k  harfe d�n��t�recek
			girilen1[j] += 32;


		if (girilen1[i] == girilen1[j])
		{
			if (i == girilen1.length() - 2)
				cout << " Evet";
			j--;
		}
		else if (girilen1[i] != girilen1[j])
		{
			cout << " Hayir ";
			break;
		}
	}


	cout << endl;

}


void noktalama(string girilen1)
{
	char isaret;
	string noktalamaisareti;
	for (int i = 0;i < girilen1.length();i++)
	{
		if (girilen1[i] > 32 && girilen1[i] < 48)
			noktalamaisareti += girilen1[i];

		else if (girilen1[i] > 57 && girilen1[i] < 65)
			noktalamaisareti += girilen1[i];

		else if (girilen1[i] > 90 && girilen1[i] < 97)
			noktalamaisareti += girilen1[i];
	}

	cout << " Girilen metindeki noktalama isaretleri : " << noktalamaisareti;
}


void kelimeharf(string girilen1)
{
	cout << endl;
	int j = 0;                                                       //ka��nc� kelime oldu�unu tuttu�umuz index
	int hsayisi = 0;
	cout << " Girilen metindeki kelimelerin harf sayilari :   ";
	for (int i = 0;i < girilen1.length();i++)
	{

		if (girilen1[i] > 96 && girilen1[i] <123)					//B�y�k harfleri kontrol eden d�ng�
			hsayisi++;


		else if (girilen1[i] > 64 && girilen1[i] < 91)				//K���k harfleri kontrol eden d�ng�
			hsayisi++;


		if (girilen1[i] == ' ')
		{
			j++;
			cout << j << ".=" << hsayisi << "    ";
			hsayisi = 0;

		}
		if (i == girilen1.length() - 1)					// en son kelimeyi yazd�rmak i�in yaz�lan if blo�u
		{
			j++;
			cout << j << ". =" << hsayisi << "  ";
			hsayisi = 0;
		}

	}

}


void kelimesesli(string girilen1)
{
	cout << endl;
	int j = 0;														//ka��nc� kelime oldu�unu tuttu�umuz index
	int seslihsayisi = 0;
	cout << " Girilen metindeki kelimelerin sesli harf sayilari :   ";
	for (int i = 0;i < girilen1.length();i++)
	{
		if (girilen1[i] == 65 || girilen1[i] == 69 || girilen1[i] == 73 || girilen1[i] == 79 || girilen1[i] == 85)                //B�y�k sesli harfleri kontrol ediyor.
			seslihsayisi++;


		else if (girilen1[i] == 97 || girilen1[i] == 101 || girilen1[i] == 105 || girilen1[i] == 111 || girilen1[i] == 117)            //K���k sesli harfleri kontrol ediyor.
			seslihsayisi++;


		if (girilen1[i] == ' ')
		{
			j++;
			cout << j << ".=" << seslihsayisi << "    ";
			seslihsayisi = 0;

		}
		if (i == girilen1.length() - 1)					// en son kelimeyi yazd�rmak i�in yaz�lan if blo�u
		{
			j++;
			cout << j << ". =" << seslihsayisi << "  ";
			seslihsayisi = 0;
		}

	}


}


void kelimepalindrommu(string girilen1)
{
	cout << endl;
	cout << " Girilen metinde palindrom kelime var mi? :   ";
	int kelimeharfsayisi = 0;
	int k, l;
	for (int i = 0;i < girilen1.length();i++)
	{


		if (girilen1[i] != ' ')
			kelimeharfsayisi++;


		if (girilen1[i] == ' ' || girilen1[i] == '.' || girilen1[i] == '?' || girilen1[i] == '!')		// . ? ! c�mle sonundaki elemanlar� kar��la�t�rmak i�in kullan�ld�.
		{

			if (girilen1[i] == '.' || girilen1[i] == '?' || girilen1[i] == '!')
			{
				k = i;
				l = i - kelimeharfsayisi + 1;
			}
			else
			{
				k = i - 1;
				l = i - kelimeharfsayisi;
			}

			for (int j = 0;j < kelimeharfsayisi - 1;j++)
			{
				if (girilen1[k] < 65 || girilen1[k] > 122)					//E�er harf de�ilse bir azaltarak di�er harfe ge�ecek(sondan ba�a gelen )
					k--;

				if (girilen1[l] < 65 || girilen1[l] > 122)					//E�er harf de�ilse bir art�rarak di�er harfe ge�ecek (ba�taaman sona do�ru gelen gelen )
					l++;

				if (girilen1[k] > 64 && girilen1[k] < 91)					//B�y�k harfi k���k  harfe d�n��t�recek
					girilen1[k] += 32;

				if (girilen1[l] > 64 && girilen1[l] < 91)					//B�y�k harfi k���k  harfe d�n��t�recek
					girilen1[l] += 32;

				if (girilen1[k] == girilen1[l])
				{
					if (j == kelimeharfsayisi - 2)
					{
						cout << " Var" << endl;
						return;
					}

				}

				else
					break;


				l++;
				k--;
			}

			kelimeharfsayisi = 0;
			if (girilen1[i] == '.')
				cout << " Yok" << endl;

		}


	}
	cout << endl;
}