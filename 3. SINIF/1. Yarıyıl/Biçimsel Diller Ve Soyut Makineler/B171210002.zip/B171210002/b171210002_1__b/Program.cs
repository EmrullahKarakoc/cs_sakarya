﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


namespace b171210002_1__b
{
    class Program
    {
        /*
         * Kabuldurumu - Agelmesindekidurum - Bgelmesindekidurum 
         * 
         */
        public static string adurumu = "1BC";
        public static string bdurumu = "1BD";
        public static string cdurumu = "1EC";
        public static string ddurumu = "1ED";
        public static string edurumu = "1ED";
        public static string OLUDURUM = "000";
        public static string suankidurum = "1AA";

        public static void DurumHesapla(string gelendurum)
        {

            if (gelendurum == "A" || gelendurum == "a")
            {
                suankidurum = adurumu;
            }
            else if (gelendurum == "B" || gelendurum == "b")
            {
                suankidurum = bdurumu;

            }
            else if (gelendurum == "C" || gelendurum == "c")
            {
                suankidurum = cdurumu;
            }
            else if (gelendurum == "D" || gelendurum == "d")
            {
                suankidurum = ddurumu;
            }
            else if (gelendurum == "E" || gelendurum == "e")
            {
                suankidurum = edurumu;
            }
            else
            {
                suankidurum = OLUDURUM;
            }

        }
        public static void YonHesapla(char gelenharf)
        {
            if (gelenharf == 'A' || gelenharf == 'a')
            {
                DurumHesapla(suankidurum[1].ToString());            //Durumlarda A gelmesi durumunda gideceği durumu 2. kolonda tanımlamıştık
            }
            else if (gelenharf == 'B' || gelenharf == 'b')
            {
                DurumHesapla(suankidurum[2].ToString());             //Durumlarda A gelmesi durumunda gideceği durumu 1. kolonda tanımlamıştık
            }
            else
            {
                suankidurum = OLUDURUM;
            }
        }
        static void Main(string[] args)
        {
            Console.WriteLine(" SORU --> (a,b) simgesinde tanımlı ve L=a*((ab)*b+ b*a)* regüler ifadesiyle sunulan dil için bir dil tanıyıcı program gerçekleyiniz.\n");
            Console.WriteLine("Tanimladiginiz ifadeyi giriniz  ......:");
            while (true)
            {

                string okunandeger;
                okunandeger = Console.ReadLine();
                char[] bolunmusokunandeger = okunandeger.ToCharArray();
                foreach (var deger in bolunmusokunandeger)
                {
                    YonHesapla(deger);
                }
                if (suankidurum[0] == '1')
                    Console.WriteLine("  TEBRİKLER...Tanimladiginiz ifade bu dile aittir......... \n");
                else if (suankidurum[0] == '0')
                    Console.WriteLine("  MALESEF.....Tanimladiginiz ifade bu dile ait degildir....\n");

                suankidurum = adurumu; /* Her seferinde en baş duruma gelmek için bu ifadeyi koydum    */

            }

        }
    }
}
