/** Automatically generated file. DO NOT MODIFY */
package com.volkanak.volkanblue;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}