// 
#include<stdio.h>

int main(int argc, char *argv[])
{
  int a, b, r;

  //a = atoi(argv[1]);
  //b = atoi(argv[2]);

  r = a + b;
  printf("Sonuc %d\n", r);

}
