// 
#include<stdio.h>

int main(int argc, char *argv[])
{
  while(1) ;
}
